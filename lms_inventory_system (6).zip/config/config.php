<?php
/**
 * Local configuration. Not meant to be committed with real credentials
 * in a real project - this file is listed in .gitignore.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'dlsjbc_lms');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'DLSJBC LMS');
define('DIGITAL_STORAGE_PATH', __DIR__ . '/../storage/digital_files');